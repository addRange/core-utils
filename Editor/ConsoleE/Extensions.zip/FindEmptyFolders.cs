﻿using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;

/// <summary>
/// Tool for Git users, it finds empty folders and folders that only contain meta files, and lets you quickly remove these folders and meta files.
/// 
/// There's a slight conflict in how Git and Unity handle empty folders. 
/// Unity creates .meta files for all folders, empty or not. 
/// Git does not track empty folders but when Unity adds a meta file for it, Git will track the meta file.
/// </summary>
public class FindEmptyFolders : AssetPostprocessor
{
	static List<string> emptyFolders;
	static string assetsString = "Assets";

	[MenuItem("Tools/Find Empty Folders")]
	public static void FindEmptyFoldersNow()
	{
		emptyFolders = new List<string>();
		string[] projectSubfolders = Directory.GetDirectories(Application.dataPath);

		foreach (var folder in projectSubfolders)
		{
			if (CheckIfEmpty(folder))
				emptyFolders.Add(folder);
		}

		ShowEmptyFoldersInLog();
	}


	static void ShowEmptyFoldersInLog()
	{
		Debug.Log("Searching for folders that are empty or only contain meta files...");

		foreach (var folderName in emptyFolders)
		{
			Debug.LogFormat("{0}  <ConsoleE_Button=FindEmptyFolders.ShowInExplorer>Show in Explorer</ConsoleE_Button>", folderName);
		}

		if (emptyFolders.Count == 0)
		{
			Debug.Log("Found 0 empty folders");
		}
		else
		{
			Debug.LogFormat("<ConsoleE_Button=FindEmptyFolders.RemoveAllEmptyFolders>Delete {0} Empty Folders</ConsoleE_Button> Click to delete all folders that only contain meta files.", emptyFolders.Count);
		}
	}

	static bool CheckIfEmpty(string path)
	{
		List<string> files = new List<string>(Directory.GetFiles(path));
		List<string> filesNotMeta = files.FindAll(file => !file.EndsWith(".meta"));

		bool isNotExistFiles = filesNotMeta.Count == 0;

		bool isSubfoldersEmpty = true;

		foreach (var dir in Directory.GetDirectories(path))
		{
			if (!CheckIfEmpty(dir))
			{
				isSubfoldersEmpty = false;
			}
			else
			{
				var d = dir.Replace(Path.AltDirectorySeparatorChar, Path.DirectorySeparatorChar);
				emptyFolders.Add(d);
			}
		}

		return isNotExistFiles && isSubfoldersEmpty;
	}

	public static void ShowInExplorer(string logEntry)
	{
		string folder = logEntry.Substring(0 ,logEntry.IndexOf("<"));
		try
		{
			System.Diagnostics.Process.Start(folder);
		}
		catch
		{
			Debug.Log("[FindEmptyFolders]: Can't open folder in explorer: " + folder);
		}
	}

	public static void RemoveAllEmptyFolders()
	{
		foreach (var folder in emptyFolders)
		{
			RemoveFolder(folder);
		}

		AssetDatabase.Refresh();
		Debug.LogFormat("[FindEmptyFolders]: {0} folders were deleted", emptyFolders.Count);
	}

	static void RemoveFolder(string path)
	{
		if (Directory.Exists(path))
		{
			Directory.Delete(path, true);
			AssetDatabase.DeleteAsset(AbsolutePathToAsset(path));

			Debug.Log("[FindEmptyFolders]: Folder was removed: " + path);
		}
	}

	static string AbsolutePathToAsset(string path)
	{
		return path.Substring(path.IndexOf(assetsString));
	}
}